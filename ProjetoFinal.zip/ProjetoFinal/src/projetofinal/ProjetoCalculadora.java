
package projetofinal;


public class ProjetoCalculadora {
    
    public double somar(double numero1, double numero2){
     
        int escolha;
        double valorSoma = numero1 + numero2;
        return valorSoma;
        
    }
    
    public double subtrair(double numero1, double numero2){
        
        double valorSubtrair = numero1 - numero2;
        return valorSubtrair;
    }
     public double mutiplicar(double numero1, double numero2){
        
        double valorMutiplicar = numero1 * numero2;
        return valorMutiplicar;
    }
     
      public double dividir(double numero1, double numero2){
        
        double valorDividir = numero1 / numero2;
        return valorDividir;
    }    
}

